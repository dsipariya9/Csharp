﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pyramid
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Any Number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i=1, old=2, New=3, k=1;
            do
            {
                int j=1;
                 do
                 {
                    if(k<=3)
                    {
                        Console.Write(k+" ");
                    }
                    else
                    {
                           k=old*New;
                           if(k>n)
                        {   
                            break;
                        }
                        Console.Write(k+" ");
                        old=New;
                        New=k;
                    }
                    k++;
                    j++;
                } while(j<=i);
                i++;
                if(k>n)
                {
                    break;
                }
                Console.WriteLine();    
            }while(i<=n);
        Console.Read();
        }
    }
}
